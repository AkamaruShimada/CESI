<?php

/**
 * Used to generate database configuration
 * Save your database configuration here
 */

// Pourquoi pas utiliser un .ENV ?
return array(
    'host' => '127.0.0.1',
    'user' => 'root',
    'password' => '',
    'port'=> 3306,
    'name' => 'mytoolbox'
);

<?php
	$server = "localhost";
	$username = "dibdd";
	$password = "cesi";
	$db = "cesibdd";
	$conn = mysqli_connect($server, $username, $password, $db);
?>